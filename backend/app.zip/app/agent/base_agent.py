from langchain_litellm import ChatLiteLLM

from app.agent.client import MCPClient
from app.agent.graph import create_agent_graph


class BaseAgent:
    """
    Main AI Agent responsible for handling user requests.

    It owns:
        - the LLM
        - the MCP client
        - the LangGraph workflow
    """

    def __init__(
        self,
        system_prompt: str,
        model: str = "groq/qwen/qwen3-32b",
        temperature: float = 0,
    ):

        self.system_prompt = system_prompt

        self.llm = ChatLiteLLM(
            model=model,
            temperature=temperature
        )

        self.client = MCPClient()

        self.graph = None


    async def initialize(self):

        tools = await self.client.get_tools()

        self.graph = create_agent_graph(
            llm=self.llm,
            TOOLS=tools,
            System_Prompt=self.system_prompt
        )


    async def invoke(
        self,
        query: str
    ):

        if self.graph is None:
            await self.initialize()


        response = await self.graph.ainvoke(
            {
                "messages": [
                    {
                        "role": "user",
                        "content": query
                    }
                ]
            }
        )


        return response["messages"][-1].content
