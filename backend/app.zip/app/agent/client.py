from langchain_mcp_adapters.client import MultiServerMCPClient
import json
from pathlib import Path


class MCPClient:

    def __init__(self):

        config = Path('configs/servers.json')

        with open(config) as f:
            self.config = json.load(f)['mcpServers']

    async def get_tools(self):

        client = MultiServerMCPClient(self.config)

        return await client.get_tools()