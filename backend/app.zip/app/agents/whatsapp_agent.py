from app.agent.base_agent import BaseAgent
from app.mcp.whatsapp.prompts import WHATSAPP_AGENT_SYSTEM_PROMPT


class WhatsAppAssistant(BaseAgent):

    def __init__(self):

        super().__init__(
            system_prompt=WHATSAPP_AGENT_SYSTEM_PROMPT
        )