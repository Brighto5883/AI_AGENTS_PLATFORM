from enum import Enum


class AgentType(str, Enum):
    ROAD = "road"
    WHATSAPP = "whatsapp"
    EMAIL = "email"


class RetrievalMethod(str, Enum):
    AUTO = "auto"
    HYBRID = "hybrid"
    VECTORLESS = "vectorless"