import asyncio

from app.core.factories import (
    create_agent_service,
    create_chat_service,
    create_history_service,
    create_road_design_agent,
    create_email_agent,
    create_whatsapp_agent,
    create_agent_router,
)


class Container:

    def __init__(self):

        self.road_agent = create_road_design_agent()

        self.whatsapp_agent = create_whatsapp_agent()

        self.email_agent = create_email_agent()

        self.agent_router = create_agent_router(
            road_agent=self.road_agent,
            whatsapp_agent=self.whatsapp_agent,
            email_agent=self.email_agent,
        )

        self.agent_service = create_agent_service(
            self.agent_router,
        )

        self.chat_service = create_chat_service(
            self.agent_service
        )

        self.history_service = create_history_service()

    async def initialize(self):
        await asyncio.gather(
            self.road_agent.initialize(),
            self.whatsapp_agent.initialize(),
            self.email_agent.initialize(),
        )
        

container = Container()