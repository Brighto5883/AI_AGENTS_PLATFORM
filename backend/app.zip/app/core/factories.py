from app.agents.road_design_agent import RoadDesignAgent
from app.services.agent_service import AgentService
from app.services.chat_service import ChatService
from app.services.history_service import HistoryService
from app.agents.whatsapp_agent import WhatsAppAssistant
from app.agents.email_agent import EmailAssistant
from app.routing.agent_router import AgentRouter



def create_road_design_agent():

    return RoadDesignAgent()

def create_whatsapp_agent():
    return WhatsAppAssistant()

def create_email_agent():
    return EmailAssistant()

def create_agent_service(router):

    return AgentService(router)

def create_agent_router(
    road_agent,
    whatsapp_agent,
    email_agent,
):
    return AgentRouter(
        road_agent=road_agent,
        whatsapp_agent=whatsapp_agent,
        email_agent=email_agent,
    )


def create_chat_service(agent_service):

    return ChatService(
        agent_service
    )


def create_history_service():

    return HistoryService()

