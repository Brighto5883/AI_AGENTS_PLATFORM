# Data layer — a real place for conversations to live
import uuid
from datetime import datetime, timezone
from sqlalchemy import String, Text, DateTime, ForeignKey, Enum as SAEnum
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.database.db import Base
import enum


class MessageDirection(str, enum.Enum):
    INBOUND = "inbound"   # from customer
    OUTBOUND = "outbound" # sent by us / drafted by AI


class WhatsAppConversation(Base):
    __tablename__ = "whatsapp_conversations"

    id: Mapped[str] = mapped_column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    customer_phone: Mapped[str] = mapped_column(String, index=True)
    customer_name: Mapped[str | None] = mapped_column(String, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=lambda: datetime.now(timezone.utc))

    messages: Mapped[list["WhatsAppMessage"]] = relationship(
        back_populates="conversation", order_by="WhatsAppMessage.created_at"
    )


class WhatsAppMessage(Base):
    __tablename__ = "whatsapp_messages"

    id: Mapped[str] = mapped_column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    conversation_id: Mapped[str] = mapped_column(ForeignKey("whatsapp_conversations.id"), index=True)
    direction: Mapped[MessageDirection] = mapped_column(SAEnum(MessageDirection))
    content: Mapped[str] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=lambda: datetime.now(timezone.utc))

    conversation: Mapped["WhatsAppConversation"] = relationship(back_populates="messages")