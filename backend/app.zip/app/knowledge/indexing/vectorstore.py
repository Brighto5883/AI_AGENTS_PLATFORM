import os
import faiss
import numpy as np
import pickle
from typing import List, Any
from sentence_transformers import SentenceTransformer
from app.knowledge.indexing.embeddings import EmbeddingPipeline
from app.core.paths import FAISS_DIR

from dotenv import load_dotenv
load_dotenv()

import os

os.environ["HF_TOKEN"] = os.getenv("HF_TOKEN")

class FaissVectorStore:
    def __init__(self, persist_dir: str = FAISS_DIR, embedding_model: str = "all-MiniLM-L6-v2", chunk_size: int = 1000, chunk_overlap: int = 200):
        self.persist_dir = persist_dir
        os.makedirs(self.persist_dir, exist_ok=True)
        self.index = None
        self.metadata = []
        self.chunks = []  # NEW: store chunks for BM25 access in search.py
        self.embedding_model = embedding_model
        self.model = SentenceTransformer(embedding_model)
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap
        print(f"[INFO] Loaded embedding model: {embedding_model}")

    def build_from_documents(self, documents: List[Any]):
        print(f"[INFO] Building vector store from {len(documents)} raw documents...")
        emb_pipe = EmbeddingPipeline(model_name=self.embedding_model, chunk_size=self.chunk_size, chunk_overlap=self.chunk_overlap)
        chunks = emb_pipe.chunk_documents(documents)
        self.chunks = chunks  # NEW: save chunks as instance variable
        embeddings = emb_pipe.embed_chunks(chunks)
        #metadatas = [{"text": chunk.page_content} for chunk in chunks]
        metadatas = []

        for chunk in chunks:
            metadata = chunk.metadata.copy()
            metadata["text"] = chunk.page_content
            metadatas.append(metadata)

        self.add_embeddings(np.array(embeddings).astype('float32'), metadatas)
        self.save()
        print(f"[INFO] Vector store built and saved to {self.persist_dir}")

    def add_embeddings(self, embeddings: np.ndarray, metadatas: List[Any] = None):
        dim = embeddings.shape[1]
        if self.index is None:
            self.index = faiss.IndexFlatL2(dim)
        self.index.add(embeddings)
        if metadatas:
            self.metadata.extend(metadatas)
        print(f"[INFO] Added {embeddings.shape[0]} vectors to Faiss index.")

    def save(self):
        faiss_path = os.path.join(self.persist_dir, "faiss.index")
        meta_path = os.path.join(self.persist_dir, "metadata.pkl")
        chunks_path = os.path.join(self.persist_dir, "chunks.pkl")  # NEW
        faiss.write_index(self.index, faiss_path)
        with open(meta_path, "wb") as f:
            pickle.dump(self.metadata, f)
        with open(chunks_path, "wb") as f:  # NEW: save chunks to disk
            pickle.dump(self.chunks, f)
        print(f"[INFO] Saved Faiss index, metadata, and chunks to {self.persist_dir}")

    def load(self):
        faiss_path = os.path.join(self.persist_dir, "faiss.index")
        meta_path = os.path.join(self.persist_dir, "metadata.pkl")
        chunks_path = os.path.join(self.persist_dir, "chunks.pkl")  # NEW
        self.index = faiss.read_index(faiss_path)
        with open(meta_path, "rb") as f:
            self.metadata = pickle.load(f)
        if os.path.exists(chunks_path):  # NEW: load chunks if they exist
            with open(chunks_path, "rb") as f:
                self.chunks = pickle.load(f)
        else:
            # Fallback: reconstruct chunk texts from metadata for BM25
            self.chunks = [type('Chunk', (), {'page_content': m["text"]})() for m in self.metadata]
            print("[WARN] chunks.pkl not found — reconstructed from metadata. Re-run build_from_documents to fix.")
        print(f"[INFO] Loaded Faiss index, metadata, and chunks from {self.persist_dir}")

    def search(self, query_embedding: np.ndarray, top_k: int = 5):
        D, I = self.index.search(query_embedding, top_k)
        results = []
        for idx, dist in zip(I[0], D[0]):
            meta = self.metadata[idx] if idx < len(self.metadata) else None
            results.append({"index": idx, "distance": dist, "metadata": meta})
        return results

    def query(self, query_text: str, top_k: int = 5):
        print(f"[INFO] Querying vector store for: '{query_text}'")
        query_emb = self.model.encode([query_text]).astype('float32')
        return self.search(query_emb, top_k=top_k)

# Example usage
if __name__ == "__main__":
    from app.knowledge.ingestion.loader import load_all_documents
    docs = load_all_documents()
    store = FaissVectorStore("faiss_store")
    store.build_from_documents(docs)
    store.load()
    print(store.query("What is attention mechanism?", top_k=3))